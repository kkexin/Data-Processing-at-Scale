package cse512

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{udf, sqrt, pow, avg, count, sum, col}
import org.apache.spark.sql.functions._

object HotcellAnalysis {
  Logger.getLogger("org.spark_project").setLevel(Level.WARN)
  Logger.getLogger("org.apache").setLevel(Level.WARN)
  Logger.getLogger("akka").setLevel(Level.WARN)
  Logger.getLogger("com").setLevel(Level.WARN)

def runHotcellAnalysis(spark: SparkSession, pointPath: String): DataFrame =
{
  // Load the original data from a data source
  var pickupInfo = spark.read.format("com.databricks.spark.csv").option("delimiter",";").option("header","false").load(pointPath);
  pickupInfo.createOrReplaceTempView("nyctaxitrips")
  pickupInfo.show()

  // Assign cell coordinates based on pickup points
  spark.udf.register("CalculateX",(pickupPoint: String)=>((
    HotcellUtils.CalculateCoordinate(pickupPoint, 0)
    )))
  spark.udf.register("CalculateY",(pickupPoint: String)=>((
    HotcellUtils.CalculateCoordinate(pickupPoint, 1)
    )))
  spark.udf.register("CalculateZ",(pickupTime: String)=>((
    HotcellUtils.CalculateCoordinate(pickupTime, 2)
    )))
  pickupInfo = spark.sql("select CalculateX(nyctaxitrips._c5),CalculateY(nyctaxitrips._c5), CalculateZ(nyctaxitrips._c1) from nyctaxitrips")
  var newCoordinateName = Seq("x", "y", "z")
  pickupInfo = pickupInfo.toDF(newCoordinateName:_*)
  pickupInfo.show()

  // Define the min and max of x, y, z
  val minX = -74.50/HotcellUtils.coordinateStep
  val maxX = -73.70/HotcellUtils.coordinateStep
  val minY = 40.50/HotcellUtils.coordinateStep
  val maxY = 40.90/HotcellUtils.coordinateStep
  val minZ = 1
  val maxZ = 31
  val numCells = (maxX - minX + 1)*(maxY - minY + 1)*(maxZ - minZ + 1)

  // YOU NEED TO CHANGE THIS PART

  // Calculate the count of taxi trips for each cell
  val countsPerCell = pickupInfo.groupBy("x", "y", "z").agg(count("*").alias("count"))

  // Calculate mean and standard deviation of counts
  val meanCount = countsPerCell.agg(avg("count")).first().getDouble(0)
  val variance = countsPerCell.agg(sum(pow(col("count") - meanCount, 2))).first().getDouble(0) / numCells
  val stdDevCount = Math.sqrt(variance)



  // Calculate Getis-Ord statistic (z-score) for each cell
  val zScores = countsPerCell
    .withColumn("z_score", (col("count") - meanCount) / stdDevCount)
    .withColumn("z_score", sum("z_score").over(Window.partitionBy("z")) / count("*").over(Window.partitionBy("z")))

  // Identify the top 50 hot spot cells
  val topHotspots = zScores.orderBy(col("z_score").desc).limit(50)

  // Return the resulting DataFrame
  topHotspots
}
}
