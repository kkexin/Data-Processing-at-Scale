package cse512

object HotzoneUtils {
  def ST_Contains(queryRectangle: String, pointString: String): Boolean = {
    // Split the query rectangle string into individual coordinates
    val rectangleCoordinates = queryRectangle.split(",").map(coord => coord.toDouble)
    val rectMinX = rectangleCoordinates(0)
    val rectMinY = rectangleCoordinates(1)
    val rectMaxX = rectangleCoordinates(2)
    val rectMaxY = rectangleCoordinates(3)

    // Split the point string into individual coordinates
    val pointCoordinates = pointString.split(",").map(coord => coord.toDouble)
    val pointX = pointCoordinates(0)
    val pointY = pointCoordinates(1)

    // Check if the point is within the rectangle
    pointX >= rectMinX && pointX <= rectMaxX && pointY >= rectMinY && pointY <= rectMaxY
  }
}